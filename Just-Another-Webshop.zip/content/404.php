<?php includeHeader(); ?>
<div class="hero-unit center">
    <h1>Page Not Found</h1>
    <p>The page you requested could not be found. Use your browsers <b>Back</b> button to navigate to the page you have prevously come from</p>
    <p><b>Or you could just press this neat little button:</b></p>
    <a href="/" class="btn btn-large btn-primary">Go back</a>
</div>
<?php includeFooter(); ?>
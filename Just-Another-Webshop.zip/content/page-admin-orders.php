<?php includeHeader(); ?>

<?php listAdminOrders(); ?>

<?php includeFooter(); ?>
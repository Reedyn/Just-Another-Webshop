<?php includeHeader(); ?>

<?php listAdminProducts(); ?>

<?php includeFooter(); ?>

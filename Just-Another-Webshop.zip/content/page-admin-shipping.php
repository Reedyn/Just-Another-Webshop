<?php includeHeader(); ?>

<?php listShipping(); ?>

<?php includeFooter(); ?>
<?php includeHeader();?>

<?php listAdminTaxanomies(); ?>

<?php includeFooter(); ?>
<?php includeHeader(); ?>

<?php listAdminUsers(); ?>

<?php includeFooter(); ?>
<?php includeHeader(); ?>

<?php listSingleProduct($_GET['product']); ?>

<?php includeFooter(); ?>
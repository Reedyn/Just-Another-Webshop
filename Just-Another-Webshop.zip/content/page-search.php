<?php includeHeader(); ?>
      <div class="row">
        <div class="col-lg-4">
          <img class="img-circle" src="/img/helmet.jpg" alt="Generic placeholder image">
          <h2>Helmets</h2>
          <h3>345$</h3>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
          <p><form method="post">
            <a href="/products/1-category/1-product-name"class="btn btn-default">View details</a>
            <button class="btn btn-primary" name="add-to-cart" value="555" type="submit">Add to cart</button></form>
          </p>
        </div><!-- /.col-lg-4 -->
        
        <div class="col-lg-4">
          <img class="img-circle" src="/img/helmet.jpg" alt="Generic placeholder image">
          <h2>Helmets</h2>
          <h3>345$</h3>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
          <p>
            <form method="post">             <a href="/products/1-category/1-product-name"class="btn btn-default">View details</a>
            <button class="btn btn-primary" name="add-to-cart" value="555" type="submit">Add to cart</button></form>
          </p>
        </div><!-- /.col-lg-4 -->
        
        <div class="col-lg-4">
          <img class="img-circle" src="/img/helmet.jpg" alt="Generic placeholder image">
          <h2>Helmets</h2>
          <h3>345$</h3>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
          <p>
            <form method="post">             <a href="/products/1-category/1-product-name"class="btn btn-default">View details</a>
            <button class="btn btn-primary" name="add-to-cart" value="666" type="submit">Add to cart</button></form>
          </p>
        </div><!-- /.col-lg-4 -->
        
        <div class="col-lg-4">
          <img class="img-circle" src="/img/helmet.jpg" alt="Generic placeholder image">
          <h2>Helmets</h2>
          <h3>345$</h3>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
          <p>
            <form method="post">             <a href="/products/1-category/1-product-name"class="btn btn-default">View details</a>
            <button class="btn btn-primary" name="add-to-cart" value="666" type="submit">Add to cart</button></form>
          </p>
        </div><!-- /.col-lg-4 -->
        

        <div class="col-lg-4">
          <img class="img-circle" src="/img/helmet.jpg" alt="Generic placeholder image">
          <h2>Helmets</h2>
          <h3>345$</h3>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
          <p>
            <form method="post">             <a href="/products/1-category/1-product-name"class="btn btn-default">View details</a>
            <button class="btn btn-primary" name="add-to-cart" value="666" type="submit">Add to cart</button></form>
          </p>
        </div><!-- /.col-lg-4 -->
        
      </div><!-- /.row -->
<?php includeFooter(); ?>
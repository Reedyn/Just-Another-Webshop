<?php
    $config = array (
        'dbHost' => 'localhost',
        'dbUser' => 'jaws',
        'dbPassword' => '555666',
        'dbName' =>    'jaws_db',
        'siteName' => 'Hockey Gear'
    );
?>
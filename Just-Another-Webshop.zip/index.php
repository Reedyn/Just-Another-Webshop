<?php   session_start();
        require_once($_SERVER['DOCUMENT_ROOT']."/core/init.php");
        router();
?>